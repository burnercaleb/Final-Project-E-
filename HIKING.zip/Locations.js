const ExploreMyState  = () => {

    const status = documet.querySelector('status');
}

    const success = (position) => {
        console.log(position)
        const latitude = position.coors.latitude;
        const longitude = positio.coors.longitude;
        console.log(latitude + longitude)
    }

    const error = ( ) =>{
        status. textContent = 'Unable to retrieve your location';
    }

     
    
    
    
    navigator.geolocation.getCurrentPosition(success, error);
    
}

document.querySelector('.find-state').addEventListener('click', ExploreMyState)
